
# Rat Hunter v1.0
Rat hunter is project to detect Trojans ,<br>
this project now supports 10 different trojans<br>
and i'm working to add more & i will add option to scan obfuscated Trojans ,<br>
if you want me add new Trojan send it to <a href="mailto:k4hawk@gmail.com">k4hawk@gmail.com</a> <br><br>
i've made this project for two reasons so you can use it to scan suspected files<br>
or you can read the source code to learn how it been made.<br>
# Operation System
<b>[+] linux</b><br>
<b>[~] Windows [soon]</b>
# Trojans Supports
Windows Trojans
<ul>
<li>888 Private Rat</li>
<li>DarkTrack</li>
<li>NjRat</li>
<li>XtermeRat</li>
<li>CyberGate</li>
<li>Quasar Rat</li>
<li>VanTomRat</li>
<li>Beast Trojan Horse</li>
</ul>
Android Trojans
<ul>
<li>SpyNote 5.0</li>
<li>DroidJack</li>
</ul>
<h1>ScreenShots</h1>
<img src="./ScreenShots/1.png">
<img src="./ScreenShots/2.png">
<br>
<hr>
<h1>Video</h1>
<a href="https://www.youtube.com/watch?v=X8rPaHKHYV4"><img src="./ScreenShots/video.png"></a>
<br>
<h1>License</h1>
<img src="./ScreenShots/wtfpl.png">

    DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
    TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
    You just DO WHAT THE FUCK YOU WANT TO.
